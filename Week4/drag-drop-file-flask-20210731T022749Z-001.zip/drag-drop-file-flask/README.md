# drag-drop-file-flask
This is file drag and drop system for flask websites.made with flask_dropzone. all credits goes to flask_dropzone developers.
